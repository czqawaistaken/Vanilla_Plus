scoreboard objectives add bwoodhoe minecraft.broken:wooden_hoe
scoreboard objectives add bwoodpick minecraft.broken:wooden_pickaxe
scoreboard objectives add bwoodsword minecraft.broken:wooden_sword
scoreboard objectives add bwoodaxe minecraft.broken:wooden_axe
scoreboard objectives add bwoodshovel minecraft.broken:wooden_shovel
scoreboard objectives add bwoodspear minecraft.broken:wooden_spear
scoreboard objectives add bgoldhoe minecraft.broken:golden_hoe
scoreboard objectives add bgoldpick minecraft.broken:golden_pickaxe
scoreboard objectives add bgoldsword minecraft.broken:golden_sword
scoreboard objectives add bgoldaxe minecraft.broken:golden_axe
scoreboard objectives add bgoldshovel minecraft.broken:golden_shovel
scoreboard objectives add bgoldspear minecraft.broken:golden_spear
scoreboard objectives add bironhoe minecraft.broken:iron_hoe
scoreboard objectives add bironpick minecraft.broken:iron_pickaxe
scoreboard objectives add bironsword minecraft.broken:iron_sword
scoreboard objectives add bironaxe minecraft.broken:iron_axe
scoreboard objectives add bironshovel minecraft.broken:iron_shovel
scoreboard objectives add bironspear minecraft.broken:iron_spear
scoreboard objectives add bcopperhoe minecraft.broken:copper_hoe
scoreboard objectives add bcopperpick minecraft.broken:copper_pickaxe
scoreboard objectives add bcoppersword minecraft.broken:copper_sword
scoreboard objectives add bcopperaxe minecraft.broken:copper_axe
scoreboard objectives add bcoppershovel minecraft.broken:copper_shovel
scoreboard objectives add bcopperspear minecraft.broken:copper_spear
scoreboard objectives add bnetheritehoe minecraft.broken:netherite_hoe
scoreboard objectives add bnetheritepick minecraft.broken:netherite_pickaxe
scoreboard objectives add bnetheritesword minecraft.broken:netherite_sword
scoreboard objectives add bnetheriteaxe minecraft.broken:netherite_axe
scoreboard objectives add bnetheriteshovel minecraft.broken:netherite_shovel
scoreboard objectives add bnetheritespear minecraft.broken:netherite_spear
scoreboard objectives add bleatherboots minecraft.broken:leather_boots
scoreboard objectives add bleatherleggings minecraft.broken:leather_leggings
scoreboard objectives add bleatherchest minecraft.broken:leather_chestplate
scoreboard objectives add bleatherhelmet minecraft.broken:leather_helmet
scoreboard objectives add bchainboots minecraft.broken:chainmail_boots
scoreboard objectives add bchainleggings minecraft.broken:chainmail_leggings
scoreboard objectives add bchainchest minecraft.broken:chainmail_chestplate
scoreboard objectives add bchainhelmet minecraft.broken:chainmail_helmet
scoreboard objectives add bgoldboots minecraft.broken:golden_boots
scoreboard objectives add bgoldleggings minecraft.broken:golden_leggings
scoreboard objectives add bgoldchest minecraft.broken:golden_chestplate
scoreboard objectives add bgoldhelmet minecraft.broken:golden_helmet
scoreboard objectives add bironboots minecraft.broken:iron_boots
scoreboard objectives add bironleggings minecraft.broken:iron_leggings
scoreboard objectives add bironchest minecraft.broken:iron_chestplate
scoreboard objectives add bironhelmet minecraft.broken:iron_helmet
scoreboard objectives add bcopperboots minecraft.broken:copper_boots
scoreboard objectives add bcopperleggings minecraft.broken:copper_leggings
scoreboard objectives add bcopperchest minecraft.broken:copper_chestplate
scoreboard objectives add bcopperhelmet minecraft.broken:copper_helmet
scoreboard objectives add bfishingrod minecraft.broken:fishing_rod
scoreboard objectives add bflintandsteel minecraft.broken:flint_and_steel
scoreboard objectives add bshears minecraft.broken:shears
scoreboard objectives add bcrossbow minecraft.broken:crossbow
scoreboard objectives add bbow minecraft.broken:bow
scoreboard objectives add bshield minecraft.broken:shield
scoreboard objectives add bturtleshell minecraft.broken:turtle_helmet
scoreboard objectives add bnetheriteboots minecraft.broken:netherite_boots
scoreboard objectives add bnetheriteleg minecraft.broken:netherite_leggings
scoreboard objectives add bnetheritechest minecraft.broken:netherite_chestplate
scoreboard objectives add bnetheritehelmet minecraft.broken:netherite_helmet


execute at @a[scores={bwoodhoe=1..}] run give @p stick
execute at @a[scores={bwoodpick=1..}] run give @p stick
execute at @a[scores={bwoodsword=1..}] run give @p stick
execute at @a[scores={bwoodaxe=1..}] run give @p stick
execute at @a[scores={bwoodshovel=1..}] run give @p stick
execute at @a[scores={bwoodspear=1..}] run give @p stick
execute at @a[scores={bgoldhoe=1..}] run give @p gold_nugget 3
execute at @a[scores={bgoldpick=1..}] run give @p gold_nugget 7
execute at @a[scores={bgoldsword=1..}] run give @p gold_nugget 5
execute at @a[scores={bgoldaxe=1..}] run give @p gold_nugget 9
execute at @a[scores={bgoldshovel=1..}] run give @p gold_nugget 2
execute at @a[scores={bgoldspear=1..}] run give @p gold_nugget 1
execute at @a[scores={bironhoe=1..}] run give @p iron_nugget 4
execute at @a[scores={bironpick=1..}] run give @p iron_nugget 8
execute at @a[scores={bironsword=1..}] run give @p iron_nugget 7
execute at @a[scores={bironaxe=1..}] run give @p iron_nugget 10
execute at @a[scores={bironshovel=1..}] run give @p iron_nugget 3
execute at @a[scores={bironspear=1..}] run give @p iron_nugget 2
execute at @a[scores={bcopperhoe=1..}] run give @p copper_nugget 4
execute at @a[scores={bcopperpick=1..}] run give @p copper_nugget 8
execute at @a[scores={bcoppersword=1..}] run give @p copper_nugget 7
execute at @a[scores={bcopperaxe=1..}] run give @p copper_nugget 10
execute at @a[scores={bcoppershovel=1..}] run give @p copper_nugget 3
execute at @a[scores={bcopperspear=1..}] run give @p copper_nugget 2
execute at @a[scores={bnetheritehoe=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheritepick=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheritesword=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheriteaxe=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheriteshovel=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheritespear=1..}] run give @p netherite_scrap
execute at @a[scores={bleatherboots=1..}] run give @p leather
execute at @a[scores={bleatherleggings=1..}] run give @p leather
execute at @a[scores={bleatherchest=1..}] run give @p leather 2
execute at @a[scores={bleatherhelmet=1..}] run give @p leather
execute at @a[scores={bchainboots=1..}] run give @p iron_nugget 2
execute at @a[scores={bchainleggings=1..}] run give @p iron_nugget 3
execute at @a[scores={bchainchest=1..}] run give @p iron_nugget 4
execute at @a[scores={bchainhelmet=1..}] run give @p iron_nugget 2
execute at @a[scores={bgoldboots=1..}] run give @p gold_nugget 6
execute at @a[scores={bgoldleggings=1..}] run give @p gold_nugget 13
execute at @a[scores={bgoldchest=1..}] run give @p gold_nugget 15
execute at @a[scores={bgoldhelmet=1..}] run give @p gold_nugget 8
execute at @a[scores={bironboots=1..}] run give @p iron_nugget 9
execute at @a[scores={bironleggings=1..}] run give @p iron_nugget 16
execute at @a[scores={bironchest=1..}] run give @p iron_nugget 18
execute at @a[scores={bironhelmet=1..}] run give @p iron_nugget 13
execute at @a[scores={bcopperboots=1..}] run give @p copper_nugget 9
execute at @a[scores={bcopperleggings=1..}] run give @p copper_nugget 16
execute at @a[scores={bcopperchest=1..}] run give @p copper_nugget 18
execute at @a[scores={bcopperhelmet=1..}] run give @p copper_nugget 13
execute at @a[scores={bfishingrod=1..}] run give @p stick
execute at @a[scores={bfishingrod=1..}] run give @p string
execute at @a[scores={bflintandsteel=1..}] run give @p flint
execute at @a[scores={bflintandsteel=1..}] run give @p iron_nugget 1
execute at @a[scores={bshears=1..}] run give @p iron_nugget 7
execute at @a[scores={bcrossbow=1..}] run give @p iron_nugget 3
execute at @a[scores={bcrossbow=1..}] run give @p stick 2
execute at @a[scores={bbow=1..}] run give @p stick
execute at @a[scores={bbow=1..}] run give @p string
execute at @a[scores={bshield=1..}] run give @p stick 6
execute at @a[scores={bshield=1..}] run give @p iron_nugget 4
execute at @a[scores={bturtleshell=1..}] run give @p turtle_scute 2
execute at @a[scores={bnetheriteboots=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheriteleg=1..}] run give @p netherite_scrap
execute at @a[scores={bnetheritechest=1..}] run give @p netherite_scrap 2
execute at @a[scores={bnetheritehelmet=1..}] run give @p netherite_scrap

 
scoreboard players set @a bwoodhoe 0
scoreboard players set @a bwoodpick 0
scoreboard players set @a bwoodsword 0
scoreboard players set @a bwoodaxe 0
scoreboard players set @a bwoodshovel 0
scoreboard players set @a bwoodspear 0
scoreboard players set @a bgoldhoe 0
scoreboard players set @a bgoldpick 0
scoreboard players set @a bgoldsword 0
scoreboard players set @a bgoldaxe 0
scoreboard players set @a bgoldshovel 0
scoreboard players set @a bgoldspear 0
scoreboard players set @a bironhoe 0
scoreboard players set @a bironpick 0
scoreboard players set @a bironsword 0
scoreboard players set @a bironaxe 0
scoreboard players set @a bironshovel 0
scoreboard players set @a bironspear 0
scoreboard players set @a bcopperhoe 0
scoreboard players set @a bcopperpick 0
scoreboard players set @a bcoppersword 0
scoreboard players set @a bcopperaxe 0
scoreboard players set @a bcoppershovel 0
scoreboard players set @a bcopperspear 0
scoreboard players set @a bnetheritehoe 0
scoreboard players set @a bnetheritepick 0
scoreboard players set @a bnetheritesword 0
scoreboard players set @a bnetheriteaxe 0
scoreboard players set @a bnetheriteshovel 0
scoreboard players set @a bnetheritespear 0
scoreboard players set @a bleatherboots 0
scoreboard players set @a bleatherleggings 0
scoreboard players set @a bleatherchest 0
scoreboard players set @a bleatherhelmet 0
scoreboard players set @a bchainboots 0
scoreboard players set @a bchainleggings 0
scoreboard players set @a bchainchest 0
scoreboard players set @a bchainhelmet 0
scoreboard players set @a bgoldboots 0
scoreboard players set @a bgoldleggings 0
scoreboard players set @a bgoldchest 0
scoreboard players set @a bgoldhelmet 0
scoreboard players set @a bironboots 0
scoreboard players set @a bironleggings 0
scoreboard players set @a bironchest 0
scoreboard players set @a bironhelmet 0
scoreboard players set @a bcopperboots 0
scoreboard players set @a bcopperleggings 0
scoreboard players set @a bcopperchest 0
scoreboard players set @a bcopperhelmet 0
scoreboard players set @a bfishingrod 0
scoreboard players set @a bflintandsteel 0
scoreboard players set @a bshears 0
scoreboard players set @a bcrossbow 0
scoreboard players set @a bbow 0
scoreboard players set @a bshield 0
scoreboard players set @a bturtleshell 0
scoreboard players set @a bnetheriteboots 0
scoreboard players set @a bnetheriteleg 0
scoreboard players set @a bnetheritechest 0
scoreboard players set @a bnetheritehelmet 0
